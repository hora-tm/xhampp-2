<?php
/*
function student_edit(){
    echo '<table>';
     if(isset($_POST['student_edit_'.$row['studentId']]))
      {
        echo '<tr>';
        echo '<td><input type="text" value="'.$row['studentId'].'" name="s_id_eddited"></td>
        <td><input type="text" value="'.$row['name'].'"  name="s_name_ediited"></td>
        <td><input type="text" value="'.$row['lastName'].'"  name="s_lastName_ediited"></td>
        <td><input type="text" value="'.$row['fieldId'].'"  name="s_fieldId_ediited"></td>
        <td><input type="text" value="'.$row['passedUnit'].'"  name="s_passedUnit_ediited"></td>  
        <td><input type="text" value="'.$row['grade'].'"  name="s_grade_ediited"></td>              
         <td><input type="submit" value="save" name="student_save"></td></tr>';
      }
      echo '</table>';
}*/

echo " say someting !";
?>