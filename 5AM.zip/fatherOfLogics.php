<?php

include("db_connectionhora.php");
global $conn;
$conn = OpenCon();

global $majorName;
$majorName = array("Computer", "Electerical", "Mechanic");