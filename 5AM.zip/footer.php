

<?php 
session_start();
echo $_SESSION['username'];
?>
<footer class="section">
	<div class="center grey-text">
		copyright 2020 laya
	</div>
</footer>
 </body>